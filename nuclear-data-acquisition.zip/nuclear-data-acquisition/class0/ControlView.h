#pragma once
#include "afxwin.h"
#include "resource.h"



// CControlView ������ͼ

class CControlView : public CFormView
{
	DECLARE_DYNCREATE(CControlView)

protected:
	CControlView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CControlView();

public:
	enum { IDD = IDD_DIALOG_CONTROL };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	CEdit m_EditPeriod;
	double m_nPeriod;
	CEdit m_EditHight;
	double m_nHight;
	CButton m_ButtonPaint;
	CButton m_ButtonClear;
	afx_msg void OnBnClickedButtonPaint();
	afx_msg void OnBnClickedButtonClear();
	afx_msg void OnMenuPaint();
	afx_msg void OnMenuClear();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	BOOL m_bCheckAuto;
	afx_msg void OnBnClickedCheckTimer();
	CString m_sStatus;
	afx_msg void OnStnClickedStaticHight();
	afx_msg void OnEnChangeEditStatus();
	double m_nCurTime;
	CButton m_ButtonStop;
	afx_msg void OnBnClickedButtonStop();
	BOOL m_bSetTime;
	CEdit m_EditTime;
	double m_nSetTime;
	afx_msg void OnBnClickedChecksettime();
	bool b_Time;
	int m_StartCh;
	int m_nStartCnt;
	int m_EndCh;
	int m_nEndCnt;
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};


