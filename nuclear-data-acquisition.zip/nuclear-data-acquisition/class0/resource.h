//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� class0.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_class0TYPE                  130
#define IDD_DIALOG_CONTROL              310
#define IDC_EDIT_PERIOD                 1000
#define IDC_EDIT_HIGHT                  1001
#define IDC_BUTTON_PAINT                1002
#define IDC_BUTTON_CLEAR                1003
#define IDC_STATIC_PERIOD               1004
#define IDC_STATIC_HIGHT                1005
#define IDC_CHECK_TIMER                 1006
#define IDC_EDIT_STATUS                 1007
#define IDC_EDIT_curTIME                1008
#define IDC_BUTTON_STOP                 1009
#define IDC_CHECK_setTIME               1010
#define IDC_EDIT_setTIME                1011
#define IDC_EDIT_startCHANNEL           1012
#define IDC_EDIT_startCOUNT             1013
#define IDC_EDIT_endCHANNEL             1014
#define IDC_EDIT5                       1015
#define IDC_EDIT_endCOUNT               1015
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_MENU                         32773
#define ID_MENU_PAINT                   32774
#define ID_MENU_CLEAR                   32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
